# সময় নিউজ — Netlify + GitHub

এটি WordPress/cPanel ছাড়াই চালানোর জন্য তৈরি করা হয়েছে।

## Netlify
1. GitHub-এ এই ফাইলগুলো একটি repository-তে upload করুন।
2. Netlify-তে GitHub repository connect করুন।
3. Build command খালি রাখুন।
4. Publish directory: `public`
5. Deploy করুন।
6. পরে somoy.news domain Netlify-এর Domain settings থেকে যুক্ত করা যাবে।

## Auto News
`public/news.json` হলো সাইটের নিউজ ডেটা। GitHub Action দিয়ে RSS feed থেকে অনুমোদিত title/summary এনে এই ফাইল update করা যাবে। এরপর Netlify নতুন deploy করবে।

পূর্ণ কপিরাইটেড article/image অনুমতি ছাড়া কপি করার ব্যবস্থা রাখা হয়নি।
