import json, os, feedparser
from datetime import datetime, timezone

# Add only feeds whose publishers permit the use of their RSS content.
FEEDS = {
    "জাতীয়": [
        # Example: "https://publisher.example/rss"
    ],
    "আন্তর্জাতিক": [],
    "খেলাধুলা": [],
    "বিনোদন": [],
    "প্রযুক্তি": [],
}
OUT="public/news.json"
items=[]
for cat, urls in FEEDS.items():
    for url in urls:
        f=feedparser.parse(url)
        for e in f.entries[:10]:
            title=e.get("title","").strip()
            link=e.get("link","").strip()
            summary=e.get("summary","").strip()
            if not title or not link: continue
            items.append({"title":title,"summary":summary,"category":cat,"date":e.get("published",""),"url":link,"image":""})
items=items[:100]
with open(OUT,"w",encoding="utf-8") as fp: json.dump(items,fp,ensure_ascii=False,indent=2)
print("saved",len(items),"news")
